  
import React  from "react";

function Header() {
  return  ( 
    <header>
      <h1 style={{color: "rgb(255, 0, 0)"}}>ShapeAI</h1>
    </header>
  );
}

export default Header;